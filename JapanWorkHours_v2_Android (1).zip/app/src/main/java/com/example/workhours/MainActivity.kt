package com.example.workhours

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.content.Context
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

data class Shift(val date: String, val hours: Double)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("work_v2", Context.MODE_PRIVATE) }
    private val shifts = mutableListOf<Shift>()
    private var wage = 1100.0
    private var jpyToCny = 0.0
    private lateinit var body: LinearLayout
    private lateinit var topStats: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        load()
        showCalendar()
    }

    private fun load() {
        wage = prefs.getFloat("wage", 1100f).toDouble()
        jpyToCny = prefs.getFloat("fx", 0f).toDouble()
        prefs.getString("shifts", "")?.takeIf { it.isNotEmpty() }?.split("|")?.forEach {
            val p = it.split(",")
            if (p.size == 2) shifts.add(Shift(p[0], p[1].toDouble()))
        }
    }

    private fun save() {
        prefs.edit()
            .putFloat("wage", wage.toFloat())
            .putFloat("fx", jpyToCny.toFloat())
            .putString("shifts", shifts.joinToString("|") { "${it.date},${it.hours}" })
            .apply()
    }

    private fun tv(text: String, size: Float, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(25,25,25))
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setOnClickListener { action() }
        }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 8)
        }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(tv(title, 32f, true))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 6, 8, 10)
        }
        nav.addView(button("▦\n日历") { showCalendar() }, LinearLayout.LayoutParams(0,70,1f))
        nav.addView(button("￥\n收入") { showIncome() }, LinearLayout.LayoutParams(0,70,1f))
        nav.addView(button("▣\n工作") { showWork() }, LinearLayout.LayoutParams(0,70,1f))
        nav.addView(button("●\n我的") { showMine() }, LinearLayout.LayoutParams(0,70,1f))
        root.addView(nav)
        body = content
        return root
    }

    private fun card(text: String): TextView =
        tv(text, 17f).apply {
            setPadding(24, 20, 24, 20)
            setBackgroundColor(Color.rgb(246,246,250))
        }

    private fun currentWeekHours(): Double {
        val cal = Calendar.getInstance()
        cal.firstDayOfWeek = Calendar.MONDAY
        val week = cal.get(Calendar.WEEK_OF_YEAR)
        val year = cal.get(Calendar.YEAR)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.JAPAN)
        return shifts.filter {
            val d = Calendar.getInstance().apply { time = sdf.parse(it.date)!! }
            d.get(Calendar.WEEK_OF_YEAR) == week && d.get(Calendar.YEAR) == year
        }.sumOf { it.hours }
    }

    private fun monthHours(): Double {
        val now = Calendar.getInstance()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.JAPAN)
        return shifts.filter {
            val d = Calendar.getInstance().apply { time = sdf.parse(it.date)!! }
            d.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
            d.get(Calendar.MONTH) == now.get(Calendar.MONTH)
        }.sumOf { it.hours }
    }

    private fun showCalendar() {
        val root = base("在日工作助手")
        val next = card("◷  下一次班次\n\n●  鱼べい后厨                         下次班次\n\n────────────────────\n本月工时                 工作天数                 本周工时\n${fmt(monthHours())}                    ${shifts.size} 天                  ${fmt(currentWeekHours())}")
        body.addView(next)
        body.addView(tv("月份        周        日        年", 16f).apply { setPadding(12,24,12,12) })
        body.addView(tv(monthTitle(), 27f, true).apply { gravity = Gravity.CENTER; setPadding(0,10,0,18) })
        val add = button("＋  添加今日班次") { addShift() }
        body.addView(add)
        body.addView(tv("\n最近记录（长按删除）", 18f, true))
        shifts.sortedByDescending { it.date }.take(10).forEach {
            body.addView(tv("●  ${it.date}      ${fmt(it.hours)}      ¥${(it.hours*wage).roundToInt()}", 17f).apply {
                setPadding(8,12,8,12)
                setOnLongClickListener { shifts.remove(it); save(); showCalendar(); true }
            })
        }
    }

    private fun monthTitle(): String {
        val c = Calendar.getInstance()
        return "${c.get(Calendar.YEAR)}年 ${c.get(Calendar.MONTH)+1}月"
    }

    private fun showIncome() {
        val root = base("收入")
        body.addView(card("本月工时\n${fmt(monthHours())}\n\n本月预计工资\n¥${(monthHours()*wage).roundToInt()}\n\n时薪\n¥${wage.roundToInt()}"))
        body.addView(button("设置时薪") { editWage() })
        body.addView(tv("\n日元 ⇄ 人民币汇率换算", 21f, true))
        body.addView(tv("当前汇率：1 日元 = ${if (jpyToCny > 0) String.format("%.4f", jpyToCny) else "未设置"} 人民币", 16f))
        body.addView(button("打开汇率换算器") { converter() })
    }

    private fun showWork() {
        val root = base("工作")
        body.addView(card("本周工时\n${fmt(currentWeekHours())} / 28小时\n\n还可以工作\n${fmt((28-currentWeekHours()).coerceAtLeast(0.0))}"))
        body.addView(button("＋ 添加班次") { addShift() })
        body.addView(tv("\n提示\n• 授课期间按你设定的 28 小时上限提醒\n• 记录保存在手机本地\n• 不需要上传在留卡", 16f))
    }

    private fun showMine() {
        val root = base("我的")
        body.addView(card("设置\n\n时薪：¥${wage.roundToInt()}\n日元→人民币汇率：${if(jpyToCny>0) jpyToCny else "未设置"}"))
        body.addView(button("设置汇率") { editFx() })
        body.addView(button("清空全部工时记录") {
            AlertDialog.Builder(this).setTitle("清空记录？").setMessage("所有工时都会删除。")
                .setNegativeButton("取消", null)
                .setPositiveButton("清空") { _, _ -> shifts.clear(); save(); showMine() }.show()
        })
    }

    private fun converter() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val jpy = EditText(this).apply { hint = "输入日元，例如 11000"; inputType = 2 }
        val cny = EditText(this).apply { hint = "输入人民币，例如 500"; inputType = 2 }
        box.addView(jpy); box.addView(cny)
        AlertDialog.Builder(this).setTitle("日元 ⇄ 人民币").setView(box)
            .setMessage("请先在“我的”里设置 1 日元 = 多少人民币。")
            .setNegativeButton("关闭", null)
            .setPositiveButton("计算") { _, _ ->
                if (jpyToCny <= 0) return@setPositiveButton
                val a = jpy.text.toString().toDoubleOrNull()
                val b = cny.text.toString().toDoubleOrNull()
                val result = when {
                    a != null -> "${a.roundToInt()} 日元 ≈ ${String.format("%.2f", a*jpyToCny)} 人民币"
                    b != null -> "${b.roundToInt()} 人民币 ≈ ${String.format("%.0f", b/jpyToCny)} 日元"
                    else -> "请输入金额"
                }
                Toast.makeText(this, result, Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun editFx() {
        val input = EditText(this).apply { inputType = 8194; setText(if(jpyToCny>0) jpyToCny.toString() else "") ; hint="例如 0.05" }
        AlertDialog.Builder(this).setTitle("设置汇率").setMessage("输入：1 日元 = 多少人民币")
            .setView(input).setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                jpyToCny = input.text.toString().toDoubleOrNull() ?: 0.0
                save(); showMine()
            }.show()
    }

    private fun editWage() {
        val input = EditText(this).apply { inputType = 2; setText(wage.roundToInt().toString()) }
        AlertDialog.Builder(this).setTitle("设置时薪").setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                wage = input.text.toString().toDoubleOrNull() ?: 1100.0
                save(); showIncome()
            }.show()
    }

    private fun addShift() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val date = EditText(this).apply { hint="日期：2026-09-21"; setText(SimpleDateFormat("yyyy-MM-dd",Locale.JAPAN).format(Date())) }
        val start = EditText(this).apply { hint="上班：09:00"; inputType=1 }
        val end = EditText(this).apply { hint="下班：17:00"; inputType=1 }
        val rest = EditText(this).apply { hint="休息分钟：60"; inputType=2 }
        box.addView(date); box.addView(start); box.addView(end); box.addView(rest)
        AlertDialog.Builder(this).setTitle("添加班次").setView(box)
            .setNegativeButton("取消",null)
            .setPositiveButton("保存") { _, _ ->
                val h = calc(start.text.toString(),end.text.toString(),rest.text.toString())
                if(h != null){ shifts.add(Shift(date.text.toString(),h)); save(); showCalendar() }
                else Toast.makeText(this,"请输入正确时间，例如 09:00",Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun calc(a:String,b:String,r:String):Double? = try {
        fun m(s:String):Int { val p=s.trim().split(":"); return p[0].toInt()*60+p[1].toInt() }
        var x=m(a); var y=m(b); if(y<x)y+=1440
        ((y-x)-(r.toIntOrNull()?:0)).coerceAtLeast(0)/60.0
    } catch(e:Exception){ null }

    private fun fmt(h:Double):String {
        val m=(h*60).roundToInt()
        return "${m/60}h ${m%60}m"
    }
}
